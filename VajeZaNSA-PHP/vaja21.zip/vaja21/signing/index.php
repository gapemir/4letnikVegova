<?php

echo 'tole je test funkcije php-ja/openssl, ki odpre certifikat in izpiše njegovo vsebino.';
echo 'rabimo, ker morajo ti podatki biti na vizualizaciji certifikata.<br />';
echo 'povezava na generator je spodaj ... ';

$mydata="-----BEGIN CERTIFICATE-----
MIIDfjCCAmagAwIBAgIKcc4QYyvJKyFWhDANBgkqhkiG9w0BAQsFADBtMRIwEAYD
VQQDEwlMb2xpcG9wc2kxFjAUBgNVBAoTDU9yYWdhbml6YWNpamExFjAUBgNVBAsT
DU9yZ2FuaS4gZW5vdGExGjAYBgkqhkiG9w0BCQEWC3J1ZGlAcm9kLnNpMQswCQYD
VQQGEwJTSTAeFw0yMzA0MTIxNjQzMTNaFw0yODA0MTIxNjQzMTNaMG0xEjAQBgNV
BAMTCUxvbGlwb3BzaTEWMBQGA1UEChMNT3JhZ2FuaXphY2lqYTEWMBQGA1UECxMN
T3JnYW5pLiBlbm90YTEaMBgGCSqGSIb3DQEJARYLcnVkaUByb2Quc2kxCzAJBgNV
BAYTAlNJMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA3RYEzsX8wUdN
YB142evwS3A1RRmdEKlAfFgpv5MRe0vVsODQf5HbHrMMnLoUFH8B3LmUbVCnXgjG
OnB42qTd6ZVG6Fcj3XXVPINoDbiQNCUZh/BvehSUev6VdGRR3wa2/yf2nEEOzD+X
pko0GZmAJZAD8urmOx0A85JpXPLG+8U6SBOx5vp648ihdUH2GciYDF6jTjJ9yAnh
oE/JfhJtH/0XSh5rVgcoZ19GW4/Hwp4rTEHIIs8OsdNV83K/19GylIVo7Mz7Ol53
tlEpJEW8ndEq/qNwp+NuCH3g7dg/IO/ug7S3GhYHmmnUl1vEcaOyuwP6iV1XE/KF
AKjYRYgkEQIDAQABoyAwHjAPBgkqhkiG9y8BAQoEAgUAMAsGA1UdDwQEAwIHgDAN
BgkqhkiG9w0BAQsFAAOCAQEADvmXl6l66zmdAqaxlFN6M9cQUJl5TZI8dXeJYJOW
m3w7CXAPQCXxLxAX+C7WZ2lFkSS92C6En/DSz/UE90hoBVs/YcSu1cKVgX//82wd
G8sNPpkBqaKuxJWbJNVL45jdWWvlYQHQ13pMVpHg+Aj+ckVkX1kYRMHCJOGJXBTW
Uk04VTDHt1Npultylgu0Vf+fY7uupevGxdt6FwUtvZAElhb+UHVhcPQShgaEfy7y
r7bwLkUSvvUyPY1voA8dacL7uZ752DcXCReyLKdIxT8piOGEGGHRqYLK1rzwM45Q
Nu2qI1WkFwnvjN4uMCGcBVaOscYp0C/SPbFmy1YYA4/pcw==
-----END CERTIFICATE-----";

echo '<pre>';
print ("\r\n begin");
print_r(openssl_x509_parse($mydata));

print ("\r\n end");
echo '</pre><p/><p />';
echo '<pre>';
echo 'Datoteka, ki generira podpisan pdf je : <a href="./example_052.php">example_052.php</a>.';
?>