<?php

require_once('tcpdf_include.php');
require('./vendor/autoload.php');

class MYPDF extends TCPDF
{
    public function ColoredTable($header, $data)
    {
        // Colors, line width and bold font
        $this->setFillColor(255, 255, 255);
        //$this->setTextColor(255);
        //$this->setDrawColor(128, 0, 0);
        $this->setLineWidth(0.3);
        $this->setFont('', 'B');
        // Header
        $w = array(30, 60, 60, 30);
        $num_headers = count($header);
        for ($i = 0; $i < $num_headers; ++$i) {
            if ($i < $num_headers / 2)
                $this->Cell($w[$i], 7, $header[$i], 'B', 0, 'L', 1);
            else
                $this->Cell($w[$i], 7, $header[$i], 'B', 0, 'R', 1);
        }
        $this->Ln();

        //data
        $fill = 0;
        $sum = 0;
        $i = 0;
        foreach ($data as $row) {
            $this->Cell($w[0], 6, $i, 0, 0, 'L', $fill);
            $this->Cell($w[1], 6, $row['strac'], 0, 0, 'L', $fill);
            $this->Cell($w[2], 6, substr($row['datum'], 0, 10), 0, 0, 'R', $fill);
            $this->Cell($w[3], 6, /*number_format*/ ($row['cena']), 0, 0, 'R', $fill);
            $this->Ln();
            $sum += $row['cena'];
            $fill = !$fill;
            $i++;
        }
        $this->Cell(array_sum($w) - $w[count($w) - 1], 6, 'skupna vsota:', 'T', 0, 'R');
        $this->Cell($w[count($w) - 1], 6, $sum, 'T', 0, 'R');
        //print_r($data);
        $this->setFont('', '');
    }
}
