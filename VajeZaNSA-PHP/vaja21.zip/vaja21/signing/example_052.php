<?php
//============================================================+
// File name   : example_052.php
// Begin       : 2009-05-07
// Last Update : 2013-05-14
//
// Description : Example 052 for TCPDF class
//               Certification Signature (experimental)
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: Certification Signature (experimental)
 * @author Nicola Asuni
 * @since 2009-05-07
 * @group security
 * @group pdf
 */


/**
 *    !- ohranjena je originalna hierrhija dokumentov, vključno z nastavitvami
 *       spodnje uporabljene konstante kot je npr. PDF_PAGE_ORIENTATION so definirane vaja
 *         config/tcpdf_config_alt.php
 *       kjer so definriane tudi vse poti do ostalih resursov 
 *
 *       pomembnejši deli so označeni s //*****<--
 */

// Include the main TCPDF library (search for installation path).
require_once('tcpdf_include.php');
require('./vendor/autoload.php');
require('./MYPDF.php');

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);


$imeStrezbe = "Simona";



//*****<- spremeni, vidno v dokumentu ... 
// set document information
$pdf->setCreator(PDF_CREATOR);                                 // lastnosti dokumenta: popravi
$pdf->setAuthor('Gasper Nemgar');                               // 
$pdf->setTitle('Podpisano poročilo ');           // Podpisano poročilo 
$pdf->setSubject('vaja 21, Podpisovanje');                            // vaja 21, Podpisovanje
$pdf->setKeywords('PDF, poročilo, el. podpis, vaja 21');

// set default header data                                     // tole je header
//$pdf->setHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE . ' 052', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->setDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->setMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->setHeaderMargin(PDF_MARGIN_HEADER);
$pdf->setFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->setAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__) . '/lang/eng.php')) {
  require_once(dirname(__FILE__) . '/lang/eng.php');
  $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

/*
NOTES:
 - To create self-signed signature: openssl req -x509 -nodes -days 365000 -newkey rsa:1024 -keyout tcpdf.crt -out tcpdf.crt
 - To export crt to p12: openssl pkcs12 -export -in tcpdf.crt -out tcpdf.p12
 - To convert pfx certificate to pem: openssl pkcs12 -in tcpdf.pfx -out tcpdf.crt -nodes
*/

//*****<--  za branje lastnosti iz vsebine certifikata
$z = file_get_contents('./certs/gasper.nemgar.si.crt');
$dataC = openssl_x509_read($z);
$dataC = openssl_x509_parse($dataC);
//print_r($dataC);


//*****<-- set certificate file crt+key, uporabi svojega
$certificate = 'file://certs/gasper.nemgar.si.crt';               // v tem sta tako cert kot ključ
$certificateKey = 'file://certs/gasper.nemgar.key';
//$certificateKey=$certificate ;
$extra = './certs/ca-chain.cert.crt';   // tole verjetno ne bo šlo


//*****<-- lokaliziraj
// set additional information
$info = array(
  'Name' => $dataC['subject']['CN'],
  'Location' => $dataC['subject']['CN'],
  'Reason' => 'podpisa naloge',
  'ContactInfo' => $dataC['issuer']['CN']
);

// set document signature : certifikat, ključ, geslo za ključ, dodaten cert, ....
//*****<-- če sta ključ in certifiakt v ločenih datotekah, je drugi argument $certificateKey
$pdf->setSignature($certificate, $certificateKey, '123456', $extra, 2, $info);

//*****<--  timestamping ne deluje (metoda ni implementirana)
//$pdf->setTimeStamp( $tsa_host = '',  $tsa_username = '',  $tsa_password = '',  $tsa_cert = '' )
$pdf->setTimeStamp('https://freetsa.org/tsr');   // no go ... ni implementirano

/*
TCPDF::setSignature( $signing_cert = '',  
                     $private_key = '',  
                     $private_key_password = '',  
                     $extracerts = '',  
                     $cert_type = 2,  $info = array(),  $approval = '' )

*/


//*****<--  če ni Č-je poiščite fonte s č-ji ...  !!!
// set font. 'helvetica' MUST be used to avoid a PHP notice from PHP 7.4+
$pdf->setFont('helvetica', '', 12);
$myfontname = TCPDF_FONTS::addTTFfont('fonts_dod/Andika-Regular.ttf', '', '', 32);
//$pdf->AddFont('Andika','','./fonts_dod/Andika-Regular.ttf');
$pdf->setFont($myfontname, '', 12);



//*****<--  tu se prične vsebina strani, 

// add a page
$pdf->AddPage();

// print a line of text
//$text = 'This is a <b color="#FF0000">digitally signed document</b> using the default (example) <b>tcpdf.crt</b> certificate.<br />To validate this signature you have to load the <b color="#006600">tcpdf.fdf</b> on the Arobat Reader to add the certificate to <i>List of Trusted Identities</i>.<br /><br />For more information check the source code of this example and the source code documentation for the <i>setSignature()</i> method.<br /><br /><a href="http://www.tcpdf.org">www.tcpdf.org</a>';
$text = 'Podjetje Nemgar<br/>(zaupno)';
$pdf->writeHTML($text, true, 0, true, 0);



// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// *** set signature appearance ***


//*****<-- certfikat :
/**
 *     certifikat se izpiše znotraj htmlcelice, sintaksa stavka je v komentarju, naredite pa takole:
 *       - naredite celico, v njenj izpišete vsebino certifikata
 *       - nad to celico z enakimi dimanzijami naredite aktivno področje s certifikatom
 *       - še prej pa nekje na tem istem podrčju izrišete sliko
 *
 *        torej gre za 3 objekte, na isti lokaciji, ki se prekrivajo:
 *          a) slika
 *          b) običajen tekst, ki kaže, kaj je v certifikatu
 *          c) certifikat (ki dejansko sam po sebi ni viden)
 */

// create content for signature (image and/or text)
$pdf->Image('images/veg4.png', 150, 35, 15, 15, 'PNG');
//$pdf->Image('images/tcpdf_signature.png', 110, 60, 15, 15, 'PNG');
//$pdf->writeHTMLCell($w, $h, $x, $y, $html_cell = '<blockquote>Digitally signed by '.$CN.' <br/>DN: '.$DN.'<br/>Date: '.$SigningTime.'</blockquote>', $border = 0, $ln = 0, $fill = 0);

$SigningTime = date("d. m. Y H:i:s");
$DN = $info['Reason'];
$kva = $html_cell = '<div valign="center" align="right" style="font-size: 9px; margin-block-start: 3em;">Elektronsko podpisal<br /><span style="font-size: 12px; font-weight:bold">' . $info['Name'] . '</span><br />v namen ' . $DN . '<br /> Dne: ' . trim($SigningTime) . '</div>';
$pdf->writeHTMLCell(50, 15, 150, 35, $kva, $border = 0, $ln = 0, $fill = 0);
//*****<-- certfikat :  pri testu pozicije nastavi border na 1, da točno vidiš, kje je , enote so v mm !

// define active area for signature appearance
$pdf->setSignatureAppearance(150, 35, 65, 15);   // page=1, rectangle 

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// *** set an empty signature appearance ***
$pdf->addEmptySignatureAppearance(150, 50, 15, 15);  //tik pod njo

// ---------------------------------------------------------

$text = '<br /><br />poročilo: mesec ' . date("n") . ' leto ' . date("Y") . "<br/><br/>filter : " . $imeStrezbe;
$pdf->writeHTML($text, true, 0, true, 0);

$text = '<div valign="center" align="center">ZADNJI IZDANI RAČUNI</div><div valign="center" align="right">(končno poročilo)</div>';
$pdf->writeHTML($text, true, 0, true, 0);

//*****<-- glej še primer 11 in primer 6
// writeHTML($html, $ln=true, $fill=false, $reseth=false, $cell=false, $align='')
// writeHTMLCell($w, $h, $x, $y, $html='', $border=0, $ln=0, $fill=0, $reseth=true, $align='', $autopadding=true)

// za tabelo pazi, da bo imela VSE celice definirane ...
// spodaj je vertikalno pozicioniranje v html z <br>, uporabiš lahko tudi pozicioniranje v pdf z (x,y) ali pa
// $pdf->Ln(2);  za 2 vrstici dol ...
$pdf->Ln(4);
$pdf->setFont('dejavusans', '', 10);  // ta ima podporo za UTF-8, helvetika ne

$header = array('st', 'stevilka racuna', 'datum računa', 'znesek');


// data loading
$ST_RACUNA = 10;
$response = file_get_contents('http://localhost/api/v1/racun/' . $ST_RACUNA);
$response = json_decode($response, true);
$strezba = $response[0]['strezba'];

$response = file_get_contents('http://localhost/api/v1/strezba/' . $strezba);
$response = json_decode($response, true);
$strezba = $response[0]['ime'];

$response = file_get_contents('http://localhost/api/v1/racun/' . $strezba);
$response = json_decode($response, true);

$off = count($response) - 10;
$response = array_splice($response, $off < 0 ? 0 : $off, 20);

// print colored table
$pdf->ColoredTable($header, $response);



/*
$html1 = '<br /><br /><br /><style>.a, th {color:green; border-bottom:1px dashed green;}</style>
<table style="border:1px solid red">
  <tr><th class="a">št.</th><th class="a">Ime</th><th>Priimek</th><th>ćetrtiđ</th></tr>
  <tr><td>1</td><td>Ibro</td><td>Ščinkvec</td><td>bez stana</td></tr>
  <tr><td>2</td><td>Žiga</td><td>Pišče</td><td></td></tr>
  <tr><td>3</td><td></td><td></td><td></td></tr>
  </table>
';
*/
//$pdf->writeHTML($html1, true, false, true, false, '');



/* poljuben custom ttf font dodaš - ta je sicer še tam, ampak če hočeš kaj drugega
$fontname = TCPDF_FONTS::addTTFfont('vendor/tecnickcom/tcpdf/fonts/arialuni/arialuni.ttf', 'TrueTypeUnicode', '', 32);
$pdf->SetFont($fontname, '', 14, '', false);
*/

$pdf->Ln(8);
$text = "<span border=\"1\">izdelano dne " . date("d.m.Y") . "</span><div align=\"right\">Izdelal: G.N.</div>";
$pdf->writeHTML($text, true, 0, true, 0);

/* as for april 2023:
Unicode, Latin2 (latin extended):
Google fonts, extended latin subset, https://fonts.google.com/?subset=latin-ext&noto.lang=cs_Latn
SIL Language Tehnology, Fonts, https://software.sil.org/fonts/
*/




//*****<-- shranjevanje kot pdf
//Close and output PDF document
$pdf->Output('example_052_podpisan.pdf', 'D');

//============================================================+
// END OF FILE
//============================================================+
