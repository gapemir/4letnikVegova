<?php

$ST_RACUNA = 10;

$response = file_get_contents('http://localhost/api/v1/racun/' . $ST_RACUNA);
$response = json_decode($response, true);
$strezba = $response[0]['strezba'];

$response = file_get_contents('http://localhost/api/v1/strezba/' . $strezba);
$response = json_decode($response, true);
$strezba = $response[0]['ime'];

$response = file_get_contents('http://localhost/api/v1/racun/' . $strezba);
$response = json_decode($response, true);

//$response = array_reverse($response, true);
$off = count($response) - 20;
$response = array_splice($response, $off < 0 ? 0 : $off, 20);


$i = 0;
echo "<table>";
foreach ($response as $key => $value) {
    echo "<tr>";
    if ($i == 0) {
        foreach ($value as $k => $v) {
            echo "<th>$k</th>";
        }
        echo "</tr><tr>";
    }
    foreach ($value as $k) {
        echo "<td>$k</td>";
    }
    echo "</tr>";
    $i++;
}
echo "</table>";
